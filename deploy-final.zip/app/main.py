# app/main.py
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
from datetime import datetime
import os

# --- Provisional logging y carga segura de settings ---
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

try:
    from app.core.config import settings  # noqa: F401 (reimport seguro)
    from app.core.openapi_compatibility import optimize_for_custom_gpt
except Exception as e:
    logger.warning("Fallo al importar settings; usando valores por defecto: %s", e)
    class _FallbackSettings:
        LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
        ENVIRONMENT = os.getenv("ENVIRONMENT", "unknown")
        APP_VERSION = os.getenv("APP_VERSION", "1.1")
        AZURE_CLIENT_ID = os.getenv("AZURE_CLIENT_ID", "")
        GOOGLE_ADS_CLIENT_ID = os.getenv("GOOGLE_ADS_CLIENT_ID", "")
        YOUTUBE_CLIENT_ID = os.getenv("YOUTUBE_CLIENT_ID", "")
        META_APP_ID = os.getenv("META_APP_ID", "")
        GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
        WP_SITE_URL = os.getenv("WP_SITE_URL", "")
        NOTION_API_KEY = os.getenv("NOTION_API_KEY", "")
        HUBSPOT_PRIVATE_APP_KEY = os.getenv("HUBSPOT_PRIVATE_APP_KEY", "")
    
    settings = _FallbackSettings()
    optimize_for_custom_gpt = lambda app: app  # Fallback function

# Logging ya configurado arriba con fallback de settings
logger = logging.getLogger(__name__)

# Importar el router de acciones
try:
    from app.api.routes.dynamics_actions import router as dynamics_router
except Exception as e:
    logger.warning("No se pudo cargar dynamics_actions: %s", e)
    dynamics_router = None

try:
    from app.api.routes.chatgpt_proxy import router as chatgpt_router
except Exception as e:
    logger.warning("No se pudo cargar chatgpt_proxy: %s", e)
    chatgpt_router = None

# Intelligent assistant router removido - archivo no existe
intelligent_assistant_router = None

try:
    from app.api.routes.workflow_manager import router as workflow_router
except Exception as e:
    logger.warning("No se pudo cargar workflow_manager: %s", e)
    workflow_router = None

try:
    from app.api.routes.whatsapp_webhook import router as whatsapp_webhook_router
except Exception as e:
    logger.warning("No se pudo cargar whatsapp_webhook: %s", e)
    whatsapp_webhook_router = None

try:
    from app.api.routes.unified_assistant import router as unified_assistant_router
except Exception as e:
    logger.warning("No se pudo cargar unified_assistant: %s", e)
    unified_assistant_router = None

try:
    from app.api.routes.assistant_selector import router as assistant_selector_router
except Exception as e:
    logger.warning("No se pudo cargar assistant_selector: %s", e)
    assistant_selector_router = None

try:
    from app.api.routes.simple_assistant import router as simple_assistant_router
except Exception as e:
    logger.warning("No se pudo cargar simple_assistant: %s", e)
    simple_assistant_router = None

try:
    from app.api.routes.debug_info import router as debug_router
except Exception as e:
    logger.warning("No se pudo cargar debug_info: %s", e)
    debug_router = None

# Lifespan manager (reemplaza @app.on_event)
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Iniciando EliteDynamicsAPI v1.1...")
    logger.info(f"Nivel de Logging configurado: {settings.LOG_LEVEL.upper()}")
    logger.info(f"Entorno: {settings.ENVIRONMENT}")
    yield
    # Shutdown
    logger.info("Apagando EliteDynamicsAPI...")

# Crear la instancia de la aplicación FastAPI con lifespan
app = FastAPI(
    title="EliteDynamicsAPI",
    description="API empresarial avanzada con 476+ integraciones - Optimizada para Custom GPT",
    version="1.1",
    docs_url="/api/v1/docs",
    redoc_url="/api/v1/redoc",
    openapi_url="/api/v1/openapi.json",
    lifespan=lifespan  # Usar lifespan en lugar de on_event
)

# 🚀 OPTIMIZAR PARA CUSTOM GPT - CAMBIAR OPENAPI DE 3.1.0 A 3.0.3
app = optimize_for_custom_gpt(app)

# CORS (ajústelo para producción: dominios específicos)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Normalización de errores 422 (validación) y 500 (genéricos) a JSON consistente
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "status": "error",
            "message": "Datos de entrada inválidos.",
            "http_status": 422,
            "details": exc.errors(),
        },
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    # Evita respuestas HTML y mantiene formato JSON homogéneo
    logger.exception("Unhandled exception: %s", exc)
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "message": "Error interno del servidor.",
            "http_status": 500,
            "details": str(exc),
        },
    )

# Incluir routers (si cargaron correctamente)
if dynamics_router is not None:
    app.include_router(dynamics_router, prefix="/api/v1")
    logger.info("Router de acciones dinámicas incluido bajo el prefijo: /api/v1")
else:
    logger.warning("Router de acciones dinámicas NO cargó; la app seguirá viva con endpoints de health.")

if chatgpt_router is not None:
    app.include_router(chatgpt_router, prefix="/api/v1")
    logger.info("Router ChatGPT Proxy incluido bajo el prefijo: /api/v1")
else:
    logger.warning("Router ChatGPT Proxy NO cargó; la app seguirá viva con endpoints de health.")

if intelligent_assistant_router is not None:
    app.include_router(intelligent_assistant_router, prefix="/api/v1/intelligent-assistant")
    logger.info("Router Asistente Inteligente incluido bajo el prefijo: /api/v1/intelligent-assistant")
else:
    logger.warning("Router Asistente Inteligente NO cargó; la app seguirá viva con endpoints de health.")

if workflow_router is not None:
    app.include_router(workflow_router, prefix="/api/v1")
    logger.info("Router Workflow Manager incluido bajo el prefijo: /api/v1")
else:
    logger.warning("Router Workflow Manager NO cargó; la app seguirá viva con endpoints de health.")

if whatsapp_webhook_router is not None:
    app.include_router(whatsapp_webhook_router)
    logger.info("Router WhatsApp Webhook incluido")
else:
    logger.warning("Router WhatsApp Webhook NO cargó; la app seguirá viva con endpoints de health.")

if unified_assistant_router is not None:
    app.include_router(unified_assistant_router, prefix="/api/v1")
    logger.info("Router Unified Assistant incluido bajo el prefijo: /api/v1")
else:
    logger.warning("Router Unified Assistant NO cargó; la app seguirá viva con endpoints de health.")

if assistant_selector_router is not None:
    app.include_router(assistant_selector_router, prefix="/api/v1")
    logger.info("Router Assistant Selector incluido bajo el prefijo: /api/v1")
else:
    logger.warning("Router Assistant Selector NO cargó; la app seguirá viva con endpoints de health.")

if simple_assistant_router is not None:
    app.include_router(simple_assistant_router, prefix="/api/v1")
    logger.info("Router Simple Assistant incluido bajo el prefijo: /api/v1")
else:
    logger.warning("Router Simple Assistant NO cargó; la app seguirá viva con endpoints de health.")

if debug_router is not None:
    app.include_router(debug_router, prefix="/api/v1")
    logger.info("Router Debug incluido bajo el prefijo: /api/v1")
else:
    logger.warning("Router Debug NO cargó; la app seguirá viva con endpoints de health.")

# Configurar archivos estáticos para la interfaz de chat
try:
    from fastapi.staticfiles import StaticFiles
    from fastapi.responses import FileResponse
    import os
    
    static_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")
    if os.path.exists(static_path):
        app.mount("/static", StaticFiles(directory=static_path), name="static")
        logger.info(f"Archivos estáticos servidos desde: {static_path}")
        
        # Ruta para la interfaz de chat
        @app.get("/chat", tags=["Interface"])
        async def serve_chat_interface():
            """Servir la interfaz de chat web con audio"""
            static_file = os.path.join(static_path, "index.html")
            if os.path.exists(static_file):
                return FileResponse(static_file)
            else:
                return {
                    "message": "Interfaz de chat no encontrada",
                    "instructions": "La interfaz está disponible en static/index.html",
                    "api_docs": "/docs"
                }
        
        logger.info("Interfaz de chat disponible en: /chat")
    else:
        logger.warning(f"Directorio static no encontrado: {static_path}")
        
except Exception as e:
    logger.warning(f"No se pudo configurar interfaz de chat: {e}")

logger.info("Documentación OpenAPI (Swagger UI) disponible en: /api/v1/docs")
logger.info("Documentación ReDoc disponible en: /api/v1/redoc")

# Endpoint de health check
@app.get("/")
async def root():
    return {
        "message": "EliteDynamicsAPI está funcionando",
        "version": "1.1",
        "docs": "/api/v1/docs",
        "environment": settings.ENVIRONMENT
    }

@app.get("/health")
async def health_check():
    """Health check endpoint básico"""
    return {
        "status": "healthy",
        "version": "1.1",
        "environment": settings.ENVIRONMENT,
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/v1/health")
async def api_health_check():
    """Health check endpoint detallado para verificar estado del sistema."""
    from importlib import import_module
    try:
        ACTION_MAP = import_module("app.core.action_mapper").ACTION_MAP
        total_actions = len(ACTION_MAP)
    except Exception as e:
        logger.warning("No se pudo cargar ACTION_MAP: %s", e)
        total_actions = 0

    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": getattr(settings, 'APP_VERSION', '1.1'),
        "environment": settings.ENVIRONMENT,
        "total_actions": total_actions,
        "backend_features": {
            "microsoft_graph": bool(getattr(settings, 'AZURE_CLIENT_ID', '')),
            "google_ads": bool(getattr(settings, 'GOOGLE_ADS_CLIENT_ID', '')),
            "youtube": bool(getattr(settings, 'YOUTUBE_CLIENT_ID', '') or getattr(settings, 'GOOGLE_ADS_CLIENT_ID', '')),
            "meta_ads": bool(getattr(settings, 'META_APP_ID', '')),
            "gemini": bool(getattr(settings, 'GEMINI_API_KEY', '')),
            "wordpress": bool(getattr(settings, 'WP_SITE_URL', '')),
            "notion": bool(getattr(settings, 'NOTION_API_KEY', '')),
            "hubspot": bool(getattr(settings, 'HUBSPOT_PRIVATE_APP_KEY', '')),
            "runway": bool(os.getenv("RUNWAY_API_KEY")),
            "auth_manager": True
        }
    }

@app.get("/api/v1/debug-imports")
async def debug_imports():
    """Endpoint para diagnosticar problemas de imports en Azure"""
    import sys
    import traceback
    from importlib import import_module
    
    debug_info = {
        "timestamp": datetime.now().isoformat(),
        "python_version": sys.version,
        "working_directory": os.getcwd(),
        "python_path": sys.path[:3],
        "import_tests": {}
    }
    
    # Probar imports críticos
    imports_to_test = [
        "app.core.config",
        "app.core.action_mapper",
        "app.core.auth_manager",
        "app.api.routes.unified_assistant",
        "app.api.routes.dynamics_actions"
    ]
    
    for module_name in imports_to_test:
        try:
            module = import_module(module_name)
            debug_info["import_tests"][module_name] = {
                "status": "SUCCESS",
                "file": getattr(module, "__file__", "unknown")
            }
        except Exception as e:
            debug_info["import_tests"][module_name] = {
                "status": "FAILED",
                "error": str(e),
                "traceback": traceback.format_exc()
            }
    
    # Probar ACTION_MAP específicamente
    try:
        from app.core.action_mapper import ACTION_MAP
        debug_info["action_map"] = {
            "status": "SUCCESS",
            "total_actions": len(ACTION_MAP),
            "sample_actions": list(ACTION_MAP.keys())[:5] if ACTION_MAP else []
        }
    except Exception as e:
        debug_info["action_map"] = {
            "status": "FAILED",
            "error": str(e),
            "traceback": traceback.format_exc()
        }
    
    return debug_info