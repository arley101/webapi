# app/api/routes/__init__.py
# Inicializa el paquete 'routes'.
# Este paquete contiene los módulos que definen los routers de FastAPI
# para los diferentes endpoints de la aplicación.