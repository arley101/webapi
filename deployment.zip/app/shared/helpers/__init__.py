# app/shared/helpers/__init__.py
# Inicializa el paquete 'helpers' dentro de 'shared'.
# Contiene clases y funciones de utilidad de propósito general, como el
# AuthenticatedHttpClient para realizar llamadas a APIs externas autenticadas.