# app/actions/__init__.py
# Este archivo inicializa el paquete 'actions'.
# Contiene todos los módulos que definen la lógica de negocio específica
# para interactuar con los diferentes servicios y APIs externas.
# (No requiere contenido adicional si solo sirve para marcar el paquete)