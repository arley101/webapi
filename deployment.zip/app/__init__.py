# app/__init__.py
# Inicializa el paquete principal 'app' de la aplicación FastAPI.
# Este archivo hace que el directorio 'app' sea reconocido como un paquete de Python,
# permitiendo importaciones relativas y una mejor organización del código.